const { DataTypes } = require('sequelize');
module.exports = (sequelize) => sequelize.define('RecurringBulkSchedule', {
  id: { type: DataTypes.BIGINT.UNSIGNED, autoIncrement: true, primaryKey: true },
  jobId: { type: DataTypes.UUID, allowNull: false },
  sourceRow: { type: DataTypes.INTEGER.UNSIGNED, allowNull: false }, // which CSV row
  frequency: { type: DataTypes.ENUM('DAILY','WEEKLY','MONTHLY'), allowNull:false },
  startDate: { type: DataTypes.DATEONLY, allowNull:false },
  untilDate: { type: DataTypes.DATEONLY, allowNull:true },
  totalOccurrences: { type: DataTypes.INTEGER.UNSIGNED, allowNull:true },
  scheduledDate: { type: DataTypes.DATEONLY, allowNull:false },
  isGenerated: { type: DataTypes.BOOLEAN, defaultValue:false },
}, {
  tableName: 'recurring_bulk_schedules',
  indexes:[{fields:['jobId']},{fields:['scheduledDate']}]
});
