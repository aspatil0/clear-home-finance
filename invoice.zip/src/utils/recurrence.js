const { addDays, addWeeks, addMonths, format } = require('date-fns');

function generateDates({ startISO, frequency, occurrences, untilISO }) {
  const out = [];
  let cur = new Date(startISO);
  for (let i=0; i<(occurrences||1000); i++) {
    const iso = format(cur, 'yyyy-MM-dd');
    out.push(iso);
    if (untilISO && iso >= untilISO) break;
    if (frequency === 'DAILY') cur = addDays(cur, 1);
    else if (frequency === 'WEEKLY') cur = addWeeks(cur, 1);
    else cur = addMonths(cur, 1);
  }
  return out;
}
module.exports = { generateDates };
