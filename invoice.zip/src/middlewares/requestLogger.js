// src/middlewares/requestLogger.js
const logger = require('../utils/logger');

function requestLogger(req, res, next) {
  // Only log write operations
  if (!['POST', 'PUT', 'DELETE'].includes(req.method)) return next();

  const start = Date.now();

  res.on('finish', () => {
    const duration = Date.now() - start;
    const message = `${req.method} ${req.originalUrl} -> ${res.statusCode} (${duration}ms)`;
    const context = [];

    if (req.body && req.body.applicationId) context.push(`applicationId=${req.body.applicationId}`);
    if (req.body && req.body.invoiceNumber) context.push(`invoiceNumber=${req.body.invoiceNumber}`);
    if (context.length) logger.info(`${message} [${context.join(', ')}]`);
    else logger.info(message);
  });

  next();
}

module.exports = requestLogger;
