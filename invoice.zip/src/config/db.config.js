// config/db.config.js
require('dotenv').config();

module.exports = {
  HOST: process.env.DB_HOST,
  USER: process.env.DB_USER,
  PASSWORD: process.env.DB_PASSWORD,
  DB: 'invoice_db_pp',
  PORT: process.env.DB_PORT,
  dialect: "mysql",
};
