const express = require('express');
const router = express.Router();
const lateFeeController = require('../controllers/lateFee.controller');
const rateLimit = require('../middlewares/rateLimit');

// Late Fee Rule (create/update)
const lateFeeRuleController = require('../controllers/lateFeeRule.controller');

router.post('/late-fee/rule', rateLimit(), lateFeeRuleController.upsertRule);

// Late Fee Apply (manual + batch)
router.post('/invoices/late-fee/apply', rateLimit(), lateFeeController.applyManual);
router.post('/invoices/late-fee/run', rateLimit(), lateFeeController.runBatch);

// GET
router.get('/late-fee/rule', lateFeeRuleController.getRuleByApp);
router.get('/late-fee/rules', lateFeeRuleController.getAllRules);

module.exports = router;
