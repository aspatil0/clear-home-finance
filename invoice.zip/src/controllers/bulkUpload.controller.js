// src/controllers/bulkUpload.controller.js
const { createBulkUploadJob, getBulkUploadJobStatus } = require('../services/bulkUpload.service');
const logger = require('../utils/logger');
const { AppError } = require('../middlewares/errorHandler');
const { RecurringBulkSchedule } = require('../models');
const axios = require('axios');
const { parse } = require('csv-parse');
const path = require('path');
const os = require('os');
const XLSX = require('xlsx');
const { validateHeaders, validateRow, normalizeHeader } = require('../utils/bulkValidators');
const FILE_SERVICE_BASE = process.env.FILE_SVC_BASE || 'http://localhost:4000';
const fs = require('fs');



// =============================
//  DRY RUN - Supports CSV + XLSX
// =============================
exports.dryRunBulkValidation = async (req, res, next) => {
  try {
    const { fileId } = req.body;
    if (!fileId)
      return res.status(400).json({ success: false, message: 'Missing fileId' });

    // Step 1: Fetch file metadata to know type
    const metaRes = await axios.get(`${FILE_SERVICE_BASE}/api/files/${fileId}`);
    const fileMeta = metaRes.data?.data || {};
    const mime = fileMeta.mimeType || '';
    const ext = path.extname(fileMeta.originalName || '').toLowerCase();

    // Step 2: Download file to temp location
    const tmpPath = path.join(os.tmpdir(), `${fileId}${ext}`);
    const response = await axios.get(`${FILE_SERVICE_BASE}/api/files/${fileId}/download`, {
      responseType: 'arraybuffer',
    });
    fs.writeFileSync(tmpPath, Buffer.from(response.data));

    let rows = [];

    // Step 3: Parse depending on type
    if (ext === '.csv' || mime.includes('csv')) {
      const text = fs.readFileSync(tmpPath, 'utf8');
      await new Promise((resolve, reject) => {
        parse(text, { columns: true, trim: true, bom: true }, (err, records) => {
          if (err) reject(err);
          rows = records;
          resolve();
        });
      });
    } else if (ext === '.xlsx' || mime.includes('spreadsheetml')) {
      const workbook = XLSX.readFile(tmpPath);
      const sheetName = workbook.SheetNames[0];
      rows = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], { defval: '' });
    } else {
      return res.status(400).json({
        success: false,
        message: `Unsupported file type (${ext || mime}). Please upload .csv or .xlsx only.`,
      });
    }

    // Step 4: Validate
    const todayISO = new Date().toISOString().slice(0, 10);
    const errors = [];
    const warnings = [];
    let total = 0;

    const headerCheck = validateHeaders(Object.keys(rows[0] || {}));
    if (!headerCheck.ok) {
      return res.status(400).json({
        success: false,
        message: 'Invalid header format',
        missing: headerCheck.missing,
      });
    }

    for (const row of rows) {
      total++;
      const normalized = {};
      for (const k in row) normalized[normalizeHeader(k)] = row[k];

      const result = validateRow({
        customerId: normalized.customerid,
        contact: normalized.contact,
        issueDate: normalized.issuedate,
        dueDate: normalized.duedate,
        totalAmount: normalized.totalamount,
        items: normalized.items,
      }, total, todayISO);

      if (!result.ok) errors.push(...result.errors);
      if (result.out.pastDueWarning)
        warnings.push({ row: total, msg: 'Past due date — will be marked expired' });
    }

    const validRecords = total - errors.length;

    res.json({
      success: true,
      message: 'Dry run completed successfully',
      summary: { totalRecords: total, validRecords, invalidRecords: errors.length },
      errors,
      warnings,
    });

    fs.unlinkSync(tmpPath); // cleanup temp file

  } catch (err) {
    logger.error(`[DryRun XLSX/CSV] ${err.message}`);
    next(err);
  }
};


/**
 * POST /api/invoices/bulk/create
 * Registers a new bulk upload job (expects a fileId from File microservice)
 */
exports.createBulkUpload = async (req, res, next) => {
  try {
    const { fileId, mode, totalRecords } = req.body;
    const createdBy = req.headers['x-user-id'] || 'system';

    if (!fileId) throw new AppError('Missing fileId (from File Service)', 400);
    if (!['one_time', 'recurring'].includes(mode)) throw new AppError('Invalid mode', 400);

    const job = await createBulkUploadJob({ fileId, mode, totalRecords, createdBy });

    res.status(201).json({
      success: true,
      message: 'Bulk upload job created successfully.',
      data: job,
    });
  } catch (err) {
    logger.error(`[BulkUpload] Create error: ${err.message}`);
    next(err);
  }
};

/**
 * GET /api/invoices/bulk/status/:jobId
 * Fetches current progress and summary of a bulk upload job.
 */
exports.getBulkUploadStatus = async (req, res, next) => {
  try {
    const { jobId } = req.params;
    if (!jobId) throw new AppError('Missing jobId', 400);

    const job = await getBulkUploadJobStatus(jobId);

    res.status(200).json({
      success: true,
      message: 'Bulk upload job status fetched successfully.',
      data: job,
    });
  } catch (err) {
    logger.error(`[BulkUpload] Status error: ${err.message}`);
    next(err);
  }
};

exports.getBulkSchedule = async (req,res,next) => {
  try {
    const { jobId } = req.params;
    const rows = await RecurringBulkSchedule.findAll({
      where: { jobId, isGenerated:false },
      order:[['scheduledDate','ASC']]
    });
    res.json({ success:true, data: rows.map(r => r.scheduledDate) });
  } catch (e) { next(e); }
};
