# payplatter-invoice-microservice
This microservice handles invoice creation (manual, scheduled, and event-based), approvals, PDF generation, and reconciliation for PayPlatter. Built using Node.js, Express, and MySQL.
