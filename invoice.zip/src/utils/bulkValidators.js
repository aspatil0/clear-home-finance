const { parse, isValid, format } = require('date-fns');
const validator = require('validator');

// strict dd-MM-yyyy → ISO
function parseDdmmyyyy(s) {
  const dt = parse(String(s).trim(), 'dd-MM-yyyy', new Date());
  if (!isValid(dt)) return null;
  return { iso: dt.toISOString().slice(0,10), pretty: format(dt, 'dd-MMM-yyyy') };
}
const tenDigit = (s) => /^[0-9]{10}$/.test(String(s).trim());
const toNumber = (s) => {
  if (s === undefined || s === null || s === '') return null;
  const n = Number(s);
  return Number.isFinite(n) ? n : null;
};

function normalizeHeader(h) { return String(h).toLowerCase().trim(); }

function validateHeaders(found) {
  const required = ['customerid','issuedate','duedate','totalamount','contact']; // items optional
  const set = new Set(found.map(normalizeHeader));
  const missing = required.filter(r => !set.has(r));
  return { ok: missing.length === 0, missing };
}

function validateRow(row, idx, todayISO) {
  const errors = [];
  const out = {};

  // customerId
  if (!row.customerId) errors.push({ row: idx, field:'customerId', msg:'Required' });
  else out.customerId = String(row.customerId).trim();

  // contact 10 digits
  if (!tenDigit(row.contact)) errors.push({ row: idx, field:'contact', msg:'Must be 10 digits' });
  else out.contact = String(row.contact).trim();

  // dates dd-MM-yyyy
  const issue = parseDdmmyyyy(row.issueDate);
  const due = parseDdmmyyyy(row.dueDate);
  if (!issue) errors.push({ row: idx, field:'issueDate', msg:'Invalid dd-mm-yyyy' });
  if (!due) errors.push({ row: idx, field:'dueDate', msg:'Invalid dd-mm-yyyy' });
  if (issue && due) {
    out.issueDate = issue.iso; out.issueDatePretty = issue.pretty;
    out.dueDate = due.iso; out.dueDatePretty = due.pretty;
    if (due.iso < issue.iso) errors.push({ row: idx, field:'dueDate', msg:'Due before issue' });
    if (due.iso < todayISO) out.pastDueWarning = true; // warn only (process allowed)
  }

  // amount
  const amt = toNumber(row.totalAmount);
  if (amt === null || amt <= 0) errors.push({ row: idx, field:'totalAmount', msg:'Must be > 0' });
  else out.totalAmount = Number(amt.toFixed(2));

  // items (optional). If absent → create default single item.
  try {
    if (row.items) {
      const parsed = typeof row.items === 'string' ? JSON.parse(row.items) : row.items;
      if (!Array.isArray(parsed) || parsed.length === 0) throw new Error('items must be array');
      out.items = parsed;
    } else {
      out.items = [{ name: 'Invoice Amount', price: out.totalAmount, quantity: 1 }];
    }
  } catch {
    errors.push({ row: idx, field:'items', msg:'Invalid JSON array' });
  }

  return { ok: errors.length === 0, out, errors };
}

module.exports = { validateHeaders, validateRow, normalizeHeader };
