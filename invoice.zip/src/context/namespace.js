// src/context/namespace.js
const { createNamespace, getNamespace } = require('cls-hooked');
const NS_NAME = 'payplatter';
const namespace = getNamespace(NS_NAME) || createNamespace(NS_NAME);

function getNamespaceSafe() {
  return namespace;
}

module.exports = { getNamespace: getNamespaceSafe };
