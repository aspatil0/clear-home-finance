// server.js
require('dotenv').config();
const app = require('./src/app'); // importing the app here
const db = require('./src/models'); // Sequelize instance

(async () => {
  try {
    await db.sequelize.sync({ alter: true });
    await db.sequelize.sync(); // avoid repetitive ALTER TABLE

    console.log('✅ Database synced successfully');

    const PORT = process.env.PORT || 5000;
    app.listen(PORT, () => {
      console.log(`Invoice microservice running on port ${PORT}`);
    });
  } catch (err) {
    console.error('DB Sync Error:', err);
    process.exit(1);
  }
})();
