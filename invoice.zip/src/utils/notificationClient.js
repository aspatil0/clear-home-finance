// ===============================================
// Notification Client Stub for PayPlatter
// ===============================================


const axios = require('axios');

// In production, point this to your real Notification microservice
const NOTIFICATION_SERVICE_URL =
  process.env.NOTIFICATION_SERVICE_URL || 'http://localhost:4000/api/notify';

/**
 * sendNotification()
 * @param {string} type - Notification type, e.g. 'invoice_created'
 * @param {object} payload - Data to send to Notification Service
 */
async function sendNotification(type, payload) {
  try {
    console.log(`[Notify] Sending ${type} → ${NOTIFICATION_SERVICE_URL}`);
    // 🔹 When Notification microservice is live, uncomment this:
    // await axios.post(NOTIFICATION_SERVICE_URL, { type, payload });
    console.log('[Notify] Payload:', payload);
  } catch (err) {
    console.error('[Notify] Failed to send notification:', err.message);
  }
}

module.exports = { sendNotification };
