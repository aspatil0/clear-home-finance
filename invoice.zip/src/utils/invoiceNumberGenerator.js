// src/utils/invoiceNumberGenerator.js
const { InvoiceSequence } = require('../models');
const { AppError } = require('../middlewares/errorHandler');

/**
 * Generates a unique invoice number per application, tenant, and year
 * Format:
 *   INV-<APPLICATIONID>-<TENANTID>-<YEAR>-<0001>
 */
async function generateInvoiceNumber(applicationId, tenantId = null) {
  if (!applicationId) {
    throw new AppError('Missing applicationId for invoice generation', 400);
  }

  const currentYear = new Date().getFullYear();
  const prefix = 'INV';

  try {
    return await InvoiceSequence.sequelize.transaction(async (t) => {
      // Find or create safely within transaction
      const [seqRecord] = await InvoiceSequence.findOrCreate({
        where: { applicationId, tenantId, year: currentYear },
        defaults: {applicationId, tenantId, year: currentYear,prefix, currentNumber: 0 
        },
        transaction: t,
        lock: true
      });

      const nextNumber = seqRecord.currentNumber + 1;
      await seqRecord.update({ currentNumber: nextNumber }, { transaction: t });

      const padded = String(nextNumber).padStart(4, '0');
      return tenantId
        ? `${prefix}-${applicationId}-${tenantId}-${currentYear}-${padded}`
        : `${prefix}-${applicationId}-${currentYear}-${padded}`;
    });
  } catch (error) {
  console.error('==============================================');
  console.error('[InvoiceGenerator] Full Sequelize error object:\n', error);
  console.error('Original error:\n', error?.original);
  console.error('SQL:\n', error?.sql);
  console.error('Fields:', error?.fields);
  console.error('Name:', error?.name);
  console.error('Errors:', error?.errors);
  console.error('==============================================');
  throw new AppError('Failed to generate invoice number', 500);
}

}

module.exports = { generateInvoiceNumber };
