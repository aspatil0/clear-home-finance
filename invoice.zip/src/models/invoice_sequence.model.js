// src/models/invoice_sequence.model.js
module.exports = (sequelize, DataTypes) => {
  const InvoiceSequence = sequelize.define('InvoiceSequence', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    applicationId: {
      type: DataTypes.STRING,
      allowNull: false
    },
    tenantId: {
    type: DataTypes.STRING,
    allowNull: true,
    comment: 'Tenant under application for per-tenant numbering'
    },
    year: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    currentNumber: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 0
    },
    prefix: {
      type: DataTypes.STRING,
      allowNull: false,
      defaultValue: 'INV'
    }
  },
  {
    indexes: [
      {
        unique: true,
        fields: ['applicationId', 'tenantId','year']
      }
    ],
    tableName: 'invoice_sequences'
  });

  return InvoiceSequence;
};
