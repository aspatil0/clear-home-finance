const { LateFeeEvent, sequelize } = require('./src/models');

(async () => {
  try {
    await sequelize.authenticate();
    console.log('Connected to DB');

    const event = await LateFeeEvent.create({
      tenantId: 'HOUSING',
      applicationId: 'HOUSING',
      invoiceId: 'ddc26b70-c098-45ae-9ea5-3e083398adb3',
      ruleId: 1,
      eventDate: new Date(),
      daysLateAppliedFor: 2,
      calculatedBase: 10000,
      amount: 150,
      reason: 'Manual sanity test'
    });

    console.log('Inserted LateFeeEvent →', event.id);
  } catch (err) {
    console.error('Error inserting LateFeeEvent:', err);
  } finally {
    await sequelize.close();
  }
})();
