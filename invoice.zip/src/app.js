// app.js
const express = require('express');
const bodyParser = require('body-parser');
const tenantContext = require('./middlewares/tenantContext'); // 

const invoiceRoutes = require('./routes/invoiceRoutes');
const bulkUploadRoutes = require('./routes/bulkUpload.routes');
const invoiceEventRoutes = require('./routes/invoiceEventRoutes');
const lateFeeRoutes = require('./routes/lateFee.routes');

const { errorHandler, notFoundHandler } = require('./middlewares/errorHandler');
const { generateInvoiceNumber } = require('./utils/invoiceNumberGenerator');
const requestLogger = require('./middlewares/requestLogger');
const cors = require('cors');

const app = express();

// ✅ ENABLE CORS FOR ALL
app.use(cors());

// (optional but recommended)
app.use(cors({
  origin: "*",
  methods: ["GET", "POST", "PUT", "DELETE", "PATCH"],
  allowedHeaders: ["Content-Type", "Authorization", "Idempotency-Key", "x-request-id"]
}));

// 1️⃣  Parse JSON bodies before routes
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.json());

// 2️⃣  Attach tenant context after parsers
app.use(tenantContext);

// 3️⃣  Application routes
app.use('/api/invoices', invoiceRoutes);
app.use('/api', lateFeeRoutes);
app.use('/api/invoice-events', invoiceEventRoutes);
app.use('/api/invoices/bulk', bulkUploadRoutes);


// 4️⃣  Logging middleware
app.use(requestLogger);

// 5️⃣  Health check route
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'invoice', time: new Date().toISOString() });
});

app.get('/test-invoice-number', async (req, res) => {
  const id = req.query.app || 'HOUSING';
  const num = await generateInvoiceNumber(id);
  res.json({ generatedNumber: num });
});

// 6️⃣  Error handling (keep at bottom)
app.use(notFoundHandler);
app.use(errorHandler);

console.log('✅ Invoice Service initialized');

module.exports = app;
