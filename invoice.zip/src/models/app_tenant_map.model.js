// src/models/app_tenant_map.model.js
module.exports = (sequelize, DataTypes) => {
  const AppTenantMap = sequelize.define('AppTenantMap', {
    id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
    applicationId: { type: DataTypes.STRING, allowNull: false },
    tenantId: { type: DataTypes.STRING, allowNull: false },
    globalTenantId: {
      type: DataTypes.UUID,
      allowNull: false,
      comment: 'References TenantMaster.globalTenantId'
    }
  }, {
    indexes: [
      { unique: true, fields: ['applicationId', 'tenantId'] }
    ],
    tableName: 'app_tenant_map'
  });
  return AppTenantMap;
};
