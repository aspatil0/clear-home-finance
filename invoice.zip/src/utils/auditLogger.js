// src/utils/auditLogger.js
const logger = require('./logger');

exports.log = async (action, details) => {
  logger.info(`[AUDIT] ${action} - ${JSON.stringify(details)}`);
};
