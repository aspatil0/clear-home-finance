// models/invoice.model.js
const { v4: uuidv4 } = require('uuid');

module.exports = (sequelize, DataTypes) => {
  const Invoice = sequelize.define("Invoice", {
    id: {
      type: DataTypes.UUID,
      defaultValue: uuidv4,
      primaryKey: true,
      comment: 'Primary key as UUID'
    },
    invoiceNumber: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
      comment: 'Auto-generated unique invoice number (displayed to users)'
    },
    idempotencyKey: {
      type: DataTypes.STRING,
      allowNull: true,
      unique: false,
      comment: 'Ensures duplicate requests don’t create multiple invoices'
    },

    customerId: {
      type: DataTypes.STRING,
      allowNull: false,
      comment: 'References the customer for whom the invoice is generated'
    },
    applicationId: {
      type: DataTypes.STRING,
      allowNull: false,
      comment: 'Represents the application under which the invoice is created'
    },
    tenantId: {
      type: DataTypes.STRING,
      allowNull: true,        // optional for backward compatibility
      comment: 'Represents tenant under application'
    },
    globalTenantId: {
    type: DataTypes.UUID,
    allowNull: true,
    comment: 'Optional link to TenantMaster for cross-app reporting'
    },

    issueDate: {
      type: DataTypes.DATEONLY,
      allowNull: false
    },
    dueDate: {
      type: DataTypes.DATEONLY,
      allowNull: false
    },
    gracePeriodDays: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    totalAmount: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: false
    },
    amountPaid: {
      type: DataTypes.DECIMAL(10, 2),
      defaultValue: 0.00
    },
    balanceAmount: {
      type: DataTypes.DECIMAL(10, 2),
      defaultValue: 0.00
    },
    lateFeeTotal: {
      type: DataTypes.DECIMAL(14, 2),
      allowNull: false,
      defaultValue: 0,
      comment: 'Total late fee amount accumulated for this invoice'
    },
    lastLateFeeCalcAt: {
      type: DataTypes.DATE,
      allowNull: true,
      comment: 'Timestamp of last late fee calculation'
    },
    status: {
      type: DataTypes.ENUM('draft', 'pending', 'approved', 'paid', 'partial', 'cancelled', 'expired'),
      defaultValue: 'draft'
    },
    items: {
      type: DataTypes.JSON,
      allowNull: false
    },
    isRecurring: {
      type: DataTypes.BOOLEAN,
      defaultValue: false
    },
    recurringRule: {
      type: DataTypes.JSON,
      allowNull: true
    },
    createdBy: {
      type: DataTypes.STRING,
      allowNull: false
    },
    updatedBy: {
      type: DataTypes.STRING,
      allowNull: true
    },
    approvedBy: {
      type: DataTypes.STRING,
      allowNull: true
    },
    approvalStatus: {
      type: DataTypes.ENUM('pending', 'approved', 'rejected'),
      defaultValue: 'pending'
    },
    approvalNotes: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    cancelledAt: {
      type: DataTypes.DATE,
      allowNull: true
    },
    cancelledBy: {
      type: DataTypes.STRING,
      allowNull: true
}

  });
  

  return Invoice;
};