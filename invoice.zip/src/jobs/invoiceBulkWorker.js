const axios = require('axios');
const { parse } = require('csv-parse');
const { BulkUploadJob, RecurringBulkSchedule, Invoice } = require('../models');
const { updateBulkUploadJob } = require('../services/bulkUpload.service');
const { validateHeaders, validateRow, normalizeHeader } = require('../utils/bulkValidators');
const { getNamespace } = require('../context/namespace');
const logger = require('../utils/logger');

const FILE_SERVICE_BASE = process.env.FILE_SVC_BASE || 'http://localhost:4000';
const PROGRESS_BATCH = 10;

async function streamCsv(fileId) {
  const url = `${FILE_SERVICE_BASE}/api/files/${fileId}/download`;
  const res = await axios.get(url, { responseType: 'stream' });
  return res.data;
}

async function createInvoiceFromRow(ns, rowOut, job) {
  // Minimal create (reuse your Invoice.create shape)
  return await Invoice.create({
    idempotencyKey: `bulk-${job.id}-${rowOut.customerId}-${rowOut.issueDate}`,
    invoiceNumber: null, // your generator runs in controller path; here keep minimal
    tenantId: ns.get('tenantId'),
    applicationId: ns.get('applicationId'),
    customerId: rowOut.customerId,
    issueDate: rowOut.issueDate,
    dueDate: rowOut.dueDate,
    totalAmount: rowOut.totalAmount,
    amountPaid: 0,
    balanceAmount: rowOut.totalAmount,
    status: (rowOut.pastDueWarning ? 'expired' : 'pending'),
    items: rowOut.items,
    currency: job.currency || 'INR',
    createdBy: ns.get('userId') || 'system'
  });
}

async function processJob(job) {
  const ns = getNamespace();
  const tenantId = ns.get('tenantId');
  const appId = ns.get('applicationId');
  logger.info(`[BulkWorker] Start job ${job.id} tenant=${tenantId} app=${appId}`);

  const stream = await streamCsv(job.fileId);
  let header;
  let rowIdx = 0;
  let processed = 0, success = 0, failure = 0;
  const errors = [];

  await updateBulkUploadJob(job.id, { status:'IN_PROGRESS', startedAt: new Date() });

  const todayISO = new Date().toISOString().slice(0,10);

  await new Promise((resolve, reject) => {
    stream.pipe(parse({ columns: true, bom:true, trim:true }))
      .on('headers', (hdrs) => {
        header = hdrs.map(normalizeHeader);
        const chk = validateHeaders(header);
        if (!chk.ok) {
          errors.push({ row: 0, field:'__header__', msg:`Missing columns: ${chk.missing.join(', ')}` });
          reject(new Error('Header validation failed'));
        }
      })
      .on('data', async (rowRaw) => {
        rowIdx++;
        try {
          // Map normalized keys
          const row = {};
          for (const k of Object.keys(rowRaw)) row[normalizeHeader(k)] = rowRaw[k];
          const vr = validateRow({
            customerId: row.customerid,
            contact: row.contact,
            issueDate: row.issuedate,
            dueDate: row.duedate,
            totalAmount: row.totalamount,
            items: row.items
          }, rowIdx, todayISO);

          if (!vr.ok) {
            failure++; errors.push(...vr.errors);
          } else {
            await createInvoiceFromRow(ns, vr.out, job);
            success++;
          }
        } catch (e) {
          failure++; errors.push({ row: rowIdx, field:'__row__', msg: e.message });
        }

        processed++;
        if (processed % PROGRESS_BATCH === 0) {
          await updateBulkUploadJob(job.id, {
            processedCount: processed,
            successCount: success,
            failureCount: failure,
            progressPercent: Number(((processed / (job.totalRecords || processed)) * 100).toFixed(2)),
            errorDetails: errors.slice(-50) // keep last 50 in row
          });
        }
      })
      .on('end', async () => {
        await updateBulkUploadJob(job.id, {
          processedCount: processed,
          successCount: success,
          failureCount: failure,
          progressPercent: 100.00,
          errorDetails: errors,
          status:'COMPLETED',
          completedAt: new Date()
        });
        logger.info(`[BulkWorker] ✅ Job ${job.id} completed: ok=${success} fail=${failure}`);
        resolve();
      })
      .on('error', async (err) => {
        logger.error(`[BulkWorker] ❌ ${job.id} failed: ${err.message}`);
        await updateBulkUploadJob(job.id, {
          status:'FAILED', errorLog: err.message, errorDetails: errors, completedAt: new Date()
        });
        reject(err);
      });
  });
}

async function processPendingJobs() {
  const jobs = await BulkUploadJob.findAll({ where: { status:'PENDING' } });
  for (const job of jobs) {
    try { await processJob(job); } catch { /* already marked */ }
  }
}

async function startWorker(intervalMs = 10000) {
  logger.info(`[BulkWorker] polling every ${intervalMs/1000}s`);
  await processPendingJobs();
  setInterval(processPendingJobs, intervalMs);
}
if (require.main === module) startWorker();

module.exports = { startWorker };
