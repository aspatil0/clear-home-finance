// src/routes/invoiceRoutes.js
const express = require('express');
const router = express.Router();
const { createInvoice, getAllInvoices, updateInvoice, getInvoiceById, deleteInvoice} = require('../controllers/invoiceController');

// Define routes (no prefix here — prefix comes from app.js)
router.post('/', createInvoice);
router.get('/', getAllInvoices);
router.get('/:id', require('../controllers/invoiceController').getInvoiceById);
router.put('/:id', require('../controllers/invoiceController').updateInvoice);
router.delete('/:id', deleteInvoice);


module.exports = router; // ✅ Export router directly
