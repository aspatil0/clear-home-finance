// src/controllers/invoiceController.js -- production version
const { v4: uuidv4 } = require('uuid');
const { Invoice, Sequelize } = require('../models');
const { Op } = Sequelize;
const Joi = require('joi');
const { getNamespace } = require('../context/namespace');
const { AppError } = require('../middlewares/errorHandler');
const { generateInvoiceNumber } = require('../utils/invoiceNumberGenerator');
const { resolveGlobalTenant } = require('../utils/globalTenantResolver');
const { log } = require('../utils/auditLogger');
const { sendNotification } = require('../utils/notificationClient');
const logger = require('../utils/logger');

// =============================
//  CREATE INVOICE
// =============================
exports.createInvoice = async (req, res, next) => {
  const requestId = req.headers['x-request-id'] || uuidv4();

  try {
    const namespace = getNamespace();
    const tenantId = namespace?.get('tenantId') || req.body.tenantId;
    const userId = namespace?.get('userId') || req.body.createdBy || 'system';
    const userRole = namespace?.get('role') || 'admin';
    const applicationId = namespace?.get('applicationId') || req.body.applicationId;
    const idempotencyKey = req.headers['idempotency-key'];

    logger.info(`[${requestId}] Incoming Invoice Create Request`);

    // Role-based Access
    if (!['admin', 'billing_manager'].includes(userRole)) {
      throw new AppError('You do not have permission to create invoices.', 403);
    }

    // Idempotency check
    if (!idempotencyKey)
      throw new AppError('Missing Idempotency-Key header', 400);

    const existing = await Invoice.findOne({ where: { idempotencyKey, tenantId } });
    if (existing) {
      return res.status(200).json({
        success: true,
        message: 'Invoice already created (idempotent replay).',
        data: existing,
      });
    }

    // Joi validation
    const schema = Joi.object({
      applicationId: Joi.string().required(),
      tenantId: Joi.string().required(),
      customerId: Joi.string().required(),
      issueDate: Joi.date().required(),
      dueDate: Joi.date().required(),
      totalAmount: Joi.number().positive().required(),
      items: Joi.array().items(
        Joi.object({
          name: Joi.string().required(),
          price: Joi.number().positive().required(),
          quantity: Joi.number().positive().required(),
        })
      ).required(),
      gracePeriodDays: Joi.number().min(0).optional(),
      description: Joi.string().allow('', null),
      createdBy: Joi.string().optional(),
    });

    const { error, value } = schema.validate(req.body);
    if (error) throw new AppError(error.details[0].message, 400);

    // Resolve global tenant
    const globalTenantId = await resolveGlobalTenant(applicationId, tenantId);

    // Generate invoice number
    const invoiceNumber = await generateInvoiceNumber(applicationId, tenantId);

    // Create invoice
    const invoice = await Invoice.create({
      id: uuidv4(),
      invoiceNumber,
      idempotencyKey,
      tenantId,
      applicationId,
      globalTenantId,
      createdBy: userId,
      status: 'pending',
      ...value,
    });

    // Log audit
    await log('invoice_created', {
      entityType: 'Invoice',
      entityId: invoice.id,
      actor: userId,
      tenantId,
      applicationId,
      globalTenantId,
      details: { invoiceNumber, totalAmount: invoice.totalAmount },
    });

    // Trigger notification
    await sendNotification('invoice_created', {
      applicationId,
      tenantId,
      globalTenantId,
      invoiceNumber,
      totalAmount: invoice.totalAmount,
      dueDate: invoice.dueDate,
    });

    res.status(201).json({
      success: true,
      message: 'Invoice created successfully.',
      data: invoice,
    });
  } catch (err) {
    logger.error(`[${requestId}] Create Invoice Error: ${err.message}`);
    next(err);
  }
};

// =============================
//  GET ALL INVOICES
// =============================
exports.getAllInvoices = async (req, res, next) => {
  try {
    const {
      page = 1,
      limit = 10,
      status,
      customerId,
      applicationId,
      tenantId,
      fromDate,
      toDate,
    } = req.query;

    const offset = (page - 1) * limit;
    const whereClause = {};

    if (status) whereClause.status = status;
    if (customerId) whereClause.customerId = customerId;
    if (applicationId) whereClause.applicationId = applicationId;
    if (tenantId) whereClause.tenantId = tenantId;

    if (fromDate && toDate) {
      whereClause.issueDate = { [Op.between]: [fromDate, toDate] };
    }

    const { count, rows } = await Invoice.findAndCountAll({
      where: whereClause,
      limit: parseInt(limit),
      offset: parseInt(offset),
      order: [['createdAt', 'DESC']],
    });

    res.status(200).json({
      success: true,
      message: 'Invoices fetched successfully',
      data: rows,
      meta: {
        page: parseInt(page),
        limit: parseInt(limit),
        totalRecords: count,
        totalPages: Math.ceil(count / limit),
      },
    });
  } catch (err) {
    next(err);
  }
};

// =============================
//  GET SINGLE INVOICE
// =============================
exports.getInvoiceById = async (req, res, next) => {
  try {
    const { id } = req.params;
    if (!id) throw new AppError('Invoice identifier missing', 400);

    const isUUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id);
    const whereClause = isUUID ? { id } : { invoiceNumber: id };

    const invoice = await Invoice.findOne({ where: whereClause });
    if (!invoice) throw new AppError('Invoice not found', 404);

    res.status(200).json({
      success: true,
      message: 'Invoice fetched successfully',
      data: invoice,
    });
  } catch (err) {
    next(err);
  }
};

// =============================
//  UPDATE INVOICE (Mark Paid / Partial)
// =============================
exports.updateInvoice = async (req, res, next) => {
  try {
    const { id } = req.params;
    const invoice = await Invoice.findByPk(id);
    if (!invoice) throw new AppError('Invoice not found', 404);

    const schema = Joi.object({
      amountPaid: Joi.number().min(0).required(),
    });
    const { error, value } = schema.validate(req.body);
    if (error) throw new AppError(error.details[0].message, 400);

    const totalAmount = parseFloat(invoice.totalAmount);
    const newAmountPaid = value.amountPaid;
    const balanceAmount = Math.max(totalAmount - newAmountPaid, 0);
    const newStatus =
      newAmountPaid === 0 ? 'pending'
      : newAmountPaid < totalAmount ? 'partial'
      : 'paid';

    await invoice.update({ amountPaid: newAmountPaid, balanceAmount, status: newStatus });

    await log('invoice_updated', {
      entityType: 'Invoice',
      entityId: invoice.id,
      details: { newStatus, amountPaid: newAmountPaid },
    });

    res.status(200).json({
      success: true,
      message: `Invoice marked as ${newStatus}`,
      data: invoice,
    });
  } catch (err) {
    next(err);
  }
};

// =============================
//  DELETE (Soft Cancel)
// =============================
exports.deleteInvoice = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { cancelledBy } = req.body;
    const invoice = await Invoice.findByPk(id);
    if (!invoice) throw new AppError('Invoice not found', 404);

    if (['paid', 'expired'].includes(invoice.status))
      throw new AppError('Paid or expired invoices cannot be cancelled.', 400);

    await invoice.update({
      status: 'cancelled',
      cancelledAt: new Date(),
      cancelledBy: cancelledBy || 'system',
    });

    await log('invoice_cancelled', {
      entityType: 'Invoice',
      entityId: invoice.id,
      actor: cancelledBy || 'system',
      details: { invoiceNumber: invoice.invoiceNumber },
    });

    await sendNotification('invoice_cancelled', {
      applicationId: invoice.applicationId,
      tenantId: invoice.tenantId,
      invoiceNumber: invoice.invoiceNumber,
    });

    res.status(200).json({
      success: true,
      message: `Invoice ${invoice.invoiceNumber} cancelled successfully.`,
      data: invoice,
    });
  } catch (err) {
    next(err);
  }
};
