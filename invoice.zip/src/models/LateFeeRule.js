// src/models/LateFeeRule.js
const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const LateFeeRule = sequelize.define('LateFeeRule', {
    id: {
      type: DataTypes.BIGINT.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
      comment: 'Primary key',
    },
    tenantId: {
      type: DataTypes.STRING(64),
      allowNull: false,
      comment: 'Tenant identifier',
    },
    applicationId: {
      type: DataTypes.STRING(64),
      allowNull: false,
      comment: 'Application identifier (e.g., HOUSING, HEALTHCARE, etc.)',
    },
    mode: {
      type: DataTypes.ENUM('MANUAL', 'AUTO', 'BOTH'),
      allowNull: false,
      defaultValue: 'MANUAL',
      comment: 'Determines if late fee applies manually, automatically, or both',
    },
    feeType: {
      type: DataTypes.ENUM('FIXED_ONCE', 'PER_DAY_FIXED', 'PER_DAY_PERCENT'),
      allowNull: false,
      defaultValue: 'PER_DAY_PERCENT',
      comment: 'Defines how the late fee is calculated',
    },
    feeValue: {
      type: DataTypes.DECIMAL(12, 4),
      allowNull: false,
      comment: 'Percentage or flat value depending on feeType',
    },
    graceDays: {
      type: DataTypes.INTEGER.UNSIGNED,
      allowNull: false,
      defaultValue: 0,
      comment: 'Number of days allowed before fee starts applying',
    },
    applyBase: {
      type: DataTypes.ENUM('PRINCIPAL', 'PRINCIPAL_PLUS_TAX', 'OUTSTANDING'),
      allowNull: false,
      defaultValue: 'OUTSTANDING',
      comment: 'Defines the base on which the late fee percentage is applied',
    },
    compounding: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false,
      comment: 'Whether to compound late fee daily (true = compound interest)',
    },
    maxCapPercentOfPrincipal: {
      type: DataTypes.DECIMAL(5, 2),
      allowNull: true,
      comment: 'Maximum cap (as % of principal) to stop further accumulation',
    },
    autoRunHourUTC: {
      type: DataTypes.TINYINT.UNSIGNED,
      allowNull: false,
      defaultValue: 0,
      comment: 'For AUTO mode, defines which UTC hour to run daily accrual',
    },
    taxCode: {
      type: DataTypes.STRING(32),
      allowNull: true,
      comment: 'Optional tax code if late fee is taxable later',
    },
    isActive: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true,
      comment: 'Marks if the rule is active or disabled',
    },
  }, {
    tableName: 'late_fee_rules',
    //schema: 'invoice_db_pp',
    timestamps: true,
    indexes: [
      { unique: true, fields: ['tenantId', 'applicationId'] },
      { fields: ['tenantId', 'isActive'] },
    ],
  });

  return LateFeeRule;
};
