// src/utils/globalTenantResolver.js
const { AppTenantMap } = require('../models');

/**
 * Resolves globalTenantId for given applicationId + tenantId
 * Returns null if mapping not found.
 */
async function resolveGlobalTenant(applicationId, tenantId) {
  if (!applicationId || !tenantId) return null;
  const mapping = await AppTenantMap.findOne({ where: { applicationId, tenantId } });
  return mapping ? mapping.globalTenantId : null;
}

module.exports = { resolveGlobalTenant };
