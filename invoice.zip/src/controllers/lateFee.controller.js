// src/controllers/lateFee.controller.js
const { v4: uuidv4 } = require('uuid');
const { Invoice, LateFeeRule } = require('../models');
const { getNamespace } = require('../context/namespace');
const { AppError } = require('../middlewares/errorHandler');
const auditLogger = require('../utils/auditLogger');
const logger = require('../utils/logger');
const Joi = require('joi');
const { applyLateFeeForInvoice } = require('../services/lateFee.service');
const { Op } = require('sequelize');

// ✅ Validation Schemas
const manualApplySchema = Joi.object({
  invoiceId: Joi.string().uuid().required(),
  asOfDate: Joi.date().iso().required(),
  daysToApply: Joi.number().integer().min(1).default(1),
  reason: Joi.string().max(200).allow('', null),
  override: Joi.object({
    feeType: Joi.string().valid('FIXED_ONCE', 'PER_DAY_FIXED', 'PER_DAY_PERCENT'),
    feeValue: Joi.number().precision(4).min(0),
    applyBase: Joi.string().valid('PRINCIPAL', 'PRINCIPAL_PLUS_TAX', 'OUTSTANDING'),
    compounding: Joi.boolean(),
    maxCapPercentOfPrincipal: Joi.number().min(0).max(100)
  }).optional(),
});

const batchRunSchema = Joi.object({
  asOfDate: Joi.date().iso().required(),
  applicationId: Joi.string().required(),
  limit: Joi.number().integer().min(1).max(5000).default(1000)
});

// 🧾 Manual Apply API
exports.applyManual = async (req, res, next) => {
  try {
    const requestId = req.headers['x-request-id'] || uuidv4();
    const idempotencyKey = req.headers['idempotency-key'] || null;
    const ns = getNamespace();
    const tenantId = ns.get('tenantId');
    const role = ns.get('role');
    const userId = ns.get('userId');

    if (!['admin', 'billing_manager'].includes(role)) {
      throw new AppError('Forbidden', 403, 'INV_4030');
    }

    const { value, error } = manualApplySchema.validate(req.body, { abortEarly: false });
    if (error) throw new AppError(error.message, 400, 'INV_4000');

    console.log('DEBUG >> tenantId:', tenantId, '| invoiceId:', value.invoiceId);

    const invoice = await Invoice.findOne({ where: { id: value.invoiceId, tenantId } });
    if (!invoice) throw new AppError('Invoice not found', 404, 'INV_4040');

    let rule = await LateFeeRule.findOne({ where: { tenantId, applicationId: invoice.applicationId, isActive: true } });
    if (!rule) throw new AppError('Late fee rule not configured', 409, 'INV_4091');

    if (rule.mode === 'AUTO' && !value.override) {
      throw new AppError('Manual application not allowed for AUTO-only mode', 409, 'INV_4092');
    }

    const effective = { ...rule.toJSON(), ...value.override };
    const result = await applyLateFeeForInvoice({
      invoice,
      rule: effective,
      asOfDate: value.asOfDate,
      daysToApply: value.daysToApply,
      reason: value.reason,
      idempotencyKey,
      actorUserId: userId
    });

    auditLogger.log('invoice.latefee.manual', { requestId, tenantId, invoiceId: invoice.id, amount: result?.amountApplied || 0 });
    return res.json({ success: true, requestId, data: result });
  } catch (err) {
    next(err);
  }
};

// 🧾 Batch Run (AUTO mode)
exports.runBatch = async (req, res, next) => {
  try {
    const requestId = req.headers['x-request-id'] || uuidv4();
    const ns = getNamespace();
    const tenantId = ns.get('tenantId');
    const role = ns.get('role');

    if (!['admin', 'billing_manager'].includes(role)) {
      throw new AppError('Forbidden', 403, 'INV_4030');
    }

    const { value, error } = batchRunSchema.validate(req.body, { abortEarly: false });
    if (error) throw new AppError(error.message, 400, 'INV_4000');

    const rule = await LateFeeRule.findOne({ where: { tenantId, applicationId: value.applicationId, isActive: true } });
    if (!rule || rule.mode === 'MANUAL') {
      throw new AppError('No eligible rule for batch run', 409, 'INV_4093');
    }

    const cutoff = new Date(value.asOfDate);
    const invoices = await Invoice.findAll({
      where: {
        tenantId,
        applicationId: value.applicationId,
        status: { [Op.in]: ['pending', 'partial', 'expired'] },
        dueDate: { [Op.lt]: cutoff },
      },
      limit: value.limit,
      order: [['id', 'ASC']]
    });

    let appliedCount = 0, totalAmount = 0;
    for (const inv of invoices) {
      const last = inv.lastLateFeeCalcAt ? new Date(inv.lastLateFeeCalcAt) : null;
      const startDate = last || new Date(inv.dueDate);
      const daysLate = Math.ceil((cutoff - startDate) / (24 * 3600 * 1000));
      const effectiveDays = Math.max(daysLate - (rule.graceDays || 0), 0);
      if (effectiveDays <= 0) continue;

      const result = await applyLateFeeForInvoice({
        invoice: inv,
        rule,
        asOfDate: value.asOfDate,
        daysToApply: effectiveDays
      });

      if (result) {
        appliedCount += 1;
        totalAmount += Number(result.amountApplied);
      }
    }

    auditLogger.log('invoice.latefee.batch', { requestId, tenantId, appliedCount, totalAmount });
    return res.json({ success: true, requestId, data: { appliedCount, totalAmount } });
  } catch (err) {
    next(err);
  }
};
