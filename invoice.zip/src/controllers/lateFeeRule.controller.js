const { getNamespace } = require('../context/namespace');
const { LateFeeRule } = require('../models');
const Joi = require('joi');
const { AppError } = require('../middlewares/errorHandler');

const ruleSchema = Joi.object({
  applicationId: Joi.string().required(),
  tenantId: Joi.string().required(),
  mode: Joi.string().valid('MANUAL', 'AUTO', 'BOTH').required(),
  feeType: Joi.string().valid('FIXED_ONCE', 'PER_DAY_FIXED', 'PER_DAY_PERCENT').required(),
  feeValue: Joi.number().precision(4).min(0).required(),
  graceDays: Joi.number().integer().min(0).default(0),
  applyBase: Joi.string().valid('PRINCIPAL', 'PRINCIPAL_PLUS_TAX', 'OUTSTANDING').required(),
  compounding: Joi.boolean().default(false),
  maxCapPercentOfPrincipal: Joi.number().min(0).max(100).allow(null),
  autoRunHourUTC: Joi.number().integer().min(0).max(23).default(0),
  isActive: Joi.boolean().default(true),
  taxCode: Joi.string().max(32).allow(null)
});

exports.upsertRule = async (req, res, next) => {
  try {
    const ns = getNamespace();
    const tenantId = ns.get('tenantId') || req.body.tenantId;
    const role = ns.get('role');

    if (!['admin', 'billing_manager'].includes(role)) {
      throw new AppError('Forbidden', 403, 'INV_4030');
    }

    const { value, error } = ruleSchema.validate(req.body, { abortEarly: false });
    if (error) throw new AppError(error.message, 400, 'INV_4000');

    const [rule, created] = await LateFeeRule.findOrCreate({
      where: { tenantId, applicationId: value.applicationId },
      defaults: { ...value, tenantId }
    });

    if (!created) await rule.update(value);

    res.json({ success: true, data: rule });
  } catch (err) {
    next(err);
  }
};

exports.getRuleByApp = async (req, res, next) => {
  try {
    // const ns = getNamespace();
    // const tenantId = ns.get('tenantId');

    const { applicationId, tenantId } = req.query;
    if (!applicationId)
      throw new AppError('applicationId is required', 400, 'INV_4001');

    const rule = await LateFeeRule.findOne({
      where: { tenantId, applicationId }
    });

    if (!rule)
      return res.json({ success: true, data: null });

    res.json({ success: true, data: rule });

  } catch (err) {
    next(err);
  }
};

exports.getAllRules = async (req, res, next) => {
  try {
    // const ns = getNamespace();
    // const tenantId = ns.get('tenantId');

    const rules = await LateFeeRule.findAll({
      // where: { tenantId },
      order: [['createdAt', 'DESC']]
    });

    res.json({ success: true, data: rules });

  } catch (err) {
    next(err);
  }
};

