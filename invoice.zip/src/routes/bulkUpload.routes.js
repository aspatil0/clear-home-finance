// src/routes/bulkUpload.routes.js
const express = require('express');
const router = express.Router();
const bulkUploadController = require('../controllers/bulkUpload.controller');


// Create new bulk job
router.post('/create', bulkUploadController.createBulkUpload);

// Get job status
router.get('/status/:jobId', bulkUploadController.getBulkUploadStatus);

// Dry run validation
router.post('/dry-run', bulkUploadController.dryRunBulkValidation);


module.exports = router;
