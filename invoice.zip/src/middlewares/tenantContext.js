// src/middlewares/tenantContext.js
const { createNamespace, getNamespace } = require('cls-hooked');
const NS_NAME = 'payplatter';
const namespace = getNamespace(NS_NAME) || createNamespace(NS_NAME);

// This middleware ensures tenant context wraps the whole request
function tenantContext(req, res, next) {
  namespace.bindEmitter(req);
  namespace.bindEmitter(res);

  namespace.run(() => {
    const tenantId = req.headers['x-tenant-id'] || 'default-tenant';
    const userId = req.headers['x-user-id'] || 'system';
    const role = req.headers['x-role'] || 'admin';

    namespace.set('tenantId', tenantId);
    namespace.set('userId', userId);
    namespace.set('role', role);

    console.log('CLS tenantContext -> tenantId:', tenantId);
    next();
  });
}

module.exports = tenantContext;
