// models/index.js
const { Sequelize } = require('sequelize');
const dbConfig = require('../config/db.config');

const sequelize = new Sequelize(dbConfig.DB, dbConfig.USER, dbConfig.PASSWORD, {
  host: dbConfig.HOST,
  port: dbConfig.PORT,
  dialect: dbConfig.dialect,
  logging: false, // Disable SQL logs in console
});

// Initialize DB object to hold models
const db = {};

db.Sequelize = Sequelize;
db.sequelize = sequelize;

// Import models here 
db.Invoice = require("./invoice.model")(sequelize, Sequelize);
db.InvoiceSequence = require('./invoice_sequence.model')(sequelize, Sequelize);

db.TenantMaster = require('./tenant_master.model')(sequelize, Sequelize);
db.AppTenantMap = require('./app_tenant_map.model')(sequelize, Sequelize);

db.InvoiceEvent = require('./invoice_event.model')(sequelize, Sequelize);
db.InvoiceEvent.belongsTo(db.Invoice, { foreignKey: 'linkedInvoiceId', as: 'invoice' });
db.Invoice.hasOne(db.InvoiceEvent, { foreignKey: 'linkedInvoiceId', as: 'event' });

db.LateFeeRule = require('./LateFeeRule')(sequelize);
db.LateFeeEvent = require('./LateFeeEvent')(sequelize);

db.BulkUploadJob = require('./BulkUploadJob')(sequelize);
db.RecurringBulkSchedule = require('./RecurringBulkSchedule')(sequelize);



// Relations
db.TenantMaster.hasMany(db.AppTenantMap, {
  foreignKey: 'globalTenantId',
  as: 'appMappings'
});
db.AppTenantMap.belongsTo(db.TenantMaster, {
  foreignKey: 'globalTenantId',
  as: 'tenantMaster'
});

db.LateFeeEvent.belongsTo(db.Invoice, { foreignKey: 'invoiceId', as: 'invoice', constraints: false });
db.LateFeeEvent.belongsTo(db.LateFeeRule, { foreignKey: 'ruleId', as: 'rule', constraints: false });




module.exports = db;
