module.exports = (options) => {
  return (req, res, next) => {
    // rate limiting logic or use express-rate-limit
    next();
  };
};
