// src/models/LateFeeEvent.js
const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const LateFeeEvent = sequelize.define('LateFeeEvent', {
    id: {
      type: DataTypes.BIGINT.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
      comment: 'Primary key',
    },
    tenantId: {
      type: DataTypes.STRING(64),
      allowNull: false,
      comment: 'Tenant identifier',
    },
    applicationId: {
      type: DataTypes.STRING(64),
      allowNull: false,
      comment: 'Application identifier (e.g., HOUSING, HEALTHCARE, etc.)',
    },
    invoiceId: {
      type: DataTypes.UUID,
      allowNull: false,
      comment: 'Reference to the affected invoice',
    },
    ruleId: {
      type: DataTypes.BIGINT.UNSIGNED,
      allowNull: true,
      comment: 'The rule under which this fee was calculated',
    },
    eventDate: {
      type: DataTypes.DATEONLY,
      allowNull: false,
      comment: 'The date for which this late fee was applied',
    },
    daysLateAppliedFor: {
      type: DataTypes.INTEGER.UNSIGNED,
      allowNull: false,
      defaultValue: 1,
      comment: 'Number of days this late fee covers',
    },
    calculatedBase: {
      type: DataTypes.DECIMAL(14, 2),
      allowNull: false,
      comment: 'The base amount on which fee was calculated',
    },
    amount: {
      type: DataTypes.DECIMAL(14, 2),
      allowNull: false,
      comment: 'Late fee amount applied in this event',
    },
    reason: {
      type: DataTypes.STRING(255),
      allowNull: true,
      comment: 'Manual reason or remark, if any',
    },
    idempotencyKey: {
      type: DataTypes.STRING(128),
      allowNull: true,
      unique: true,
      comment: 'Ensures repeated same requests don’t duplicate',
    },
    createdBy: {
      type: DataTypes.STRING(64),
      allowNull: true,
      comment: 'User ID or system identifier who triggered the event',
    },
  }, {
    tableName: 'late_fee_events',
    //schema: 'invoice_db_pp',
    timestamps: true,
    indexes: [
      { fields: ['tenantId', 'applicationId', 'invoiceId'] },
    ],
  });

  return LateFeeEvent;
};
