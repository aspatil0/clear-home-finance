// src/middlewares/errorHandler.js
class AppError extends Error {
  constructor(message, statusCode = 500, errorCode = null) {
    super(message);
    this.name = 'AppError';
    this.statusCode = statusCode;
    this.errorCode = errorCode;
  }
}

// 404 handler
function notFoundHandler(req, res, next) {
  res.status(404).json({
    success: false,
    message: `Route not found: ${req.originalUrl}`
  });
}

// Centralized error handler

function errorHandler(err, req, res, next) {
  const status = err.statusCode || 500;
  const message = err.message || 'Internal Server Error';
  const errorCode = err.errorCode || 'INV_5000';

  // Log internal details only in dev mode
  if (process.env.NODE_ENV !== 'production') {
    console.error(`[ErrorHandler] ${err.stack}`);
  }

  res.status(status).json({
    success: false,
    message,
    errorCode
  });
}


module.exports = { AppError, errorHandler, notFoundHandler };
