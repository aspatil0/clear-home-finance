// src/services/bulkUpload.service.js
const { BulkUploadJob } = require('../models');
const { getNamespace } = require('../context/namespace');
const logger = require('../utils/logger');
const { v4: uuidv4 } = require('uuid');

/**
 * Create a new bulk upload job.
 * This does not parse the file — only registers metadata and marks job as pending.
 */
async function createBulkUploadJob({ fileId, mode = 'one_time', totalRecords = 0, createdBy }) {
  const ns = getNamespace();
  const tenantId = ns.get('tenantId');
  const applicationId = ns.get('applicationId') || 'DEFAULT_APP';

  const jobId = uuidv4();

  logger.info(`[BulkUpload] Creating job for tenant=${tenantId}, app=${applicationId}, fileId=${fileId}`);

  const job = await BulkUploadJob.create({
    id: jobId,
    tenantId,
    applicationId,
    fileId,
    mode,
    totalRecords,
    createdBy,
    status: 'PENDING'
  });

  return job;
}

/**
 * Fetch status of an existing bulk upload job.
 */
async function getBulkUploadJobStatus(jobId) {
  const job = await BulkUploadJob.findByPk(jobId);

  if (!job) {
    const err = new Error(`Bulk upload job not found: ${jobId}`);
    err.statusCode = 404;
    throw err;
  }

  return job;
}

/**
 * Update job status (used later by worker)
 */
async function updateBulkUploadJob(jobId, updates) {
  const job = await BulkUploadJob.findByPk(jobId);
  if (!job) return null;

  await job.update(updates);
  logger.info(`[BulkUpload] Job ${jobId} updated: ${JSON.stringify(updates)}`);
  return job;
}

module.exports = {
  createBulkUploadJob,
  getBulkUploadJobStatus,
  updateBulkUploadJob,
};
