// src/jobs/invoiceBulkWorker.js
const { BulkUploadJob } = require('../models');
const logger = require('../utils/logger');
const { updateBulkUploadJob } = require('../services/bulkUpload.service');

/**
 * Simulated bulk invoice processor.
 * Eventually this will:
 *  - Fetch file from File Service by fileId
 *  - Parse rows (CSV/Excel)
 *  - Validate + call createInvoice() for each
 */
async function processPendingJobs() {
  logger.info('[BulkWorker] Scanning for pending bulk upload jobs...');

  const pendingJobs = await BulkUploadJob.findAll({ where: { status: 'PENDING' } });
  if (!pendingJobs.length) {
    logger.info('[BulkWorker] No pending jobs found.');
    return;
  }

  for (const job of pendingJobs) {
    try {
      logger.info(`[BulkWorker] Processing job ${job.id} (tenant=${job.tenantId})`);
      await updateBulkUploadJob(job.id, { status: 'IN_PROGRESS', startedAt: new Date() });

      // Simulate file parsing and invoice creation (for now)
      const total = job.totalRecords || 10;
      let success = 0, failure = 0;
      for (let i = 0; i < total; i++) {
        const isSuccess = Math.random() > 0.1; // 90% success simulation
        isSuccess ? success++ : failure++;
        await new Promise(r => setTimeout(r, 100)); // simulate processing delay
      }

      await updateBulkUploadJob(job.id, {
        successCount: success,
        failureCount: failure,
        status: failure > 0 ? 'COMPLETED' : 'COMPLETED',
        completedAt: new Date(),
      });

      logger.info(`[BulkWorker] ✅ Job ${job.id} completed (${success} success, ${failure} failed).`);
    } catch (err) {
      logger.error(`[BulkWorker] ❌ Error processing job ${job.id}: ${err.message}`);
      await updateBulkUploadJob(job.id, {
        status: 'FAILED',
        errorLog: err.message,
        completedAt: new Date(),
      });
    }
  }
}

/**
 * Schedule to run every N seconds (manual simulation for now)
 * Later can be replaced with a queue or cron trigger.
 */
async function startWorker(intervalMs = 10000) {
  logger.info(`[BulkWorker] Initialized. Polling every ${intervalMs / 1000}s...`);
  await processPendingJobs();
  setInterval(processPendingJobs, intervalMs);
}

// Allow manual run: `node src/jobs/invoiceBulkWorker.js`
if (require.main === module) {
  (async () => {
    await startWorker(10000);
  })();
}

module.exports = { startWorker };
