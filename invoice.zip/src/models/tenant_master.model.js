// src/models/tenant_master.model.js
module.exports = (sequelize, DataTypes) => {
  const TenantMaster = sequelize.define('TenantMaster', {
    globalTenantId: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false
    },
    contactEmail: DataTypes.STRING,
    contactPhone: DataTypes.STRING,
    metadata: DataTypes.JSON
  }, {
    tableName: 'tenant_master'
  });
  return TenantMaster;
};
