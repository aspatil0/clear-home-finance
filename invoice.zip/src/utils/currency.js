function formatINR(n, currency='INR') {
  try {
    return new Intl.NumberFormat('en-IN', { style:'currency', currency }).format(Number(n));
  } catch { return String(n); }
}
module.exports = { formatINR };
