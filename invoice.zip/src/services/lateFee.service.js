// src/services/lateFee.service.js
const { Op } = require('sequelize');
const { Invoice, LateFeeRule, LateFeeEvent, sequelize } = require('../models');
const { getNamespace } = require('../context/namespace');
const auditLogger = require('../utils/auditLogger');
const { AppError } = require('../middlewares/errorHandler');

// Helper: round to 2 decimals
const round2 = (n) => Number.parseFloat(Number(n).toFixed(2));

// Helper: compute outstanding base
const computeBase = (invoice, applyBase) => {
  const principal = Number(invoice.subtotal || invoice.amount || invoice.totalAmount || 0);
  const tax = Number(invoice.taxTotal || 0);
  const paid = Number(invoice.amountPaid || 0);
  const late = Number(invoice.lateFeeTotal || 0);
  const discount = Number(invoice.discountTotal || 0);

  switch (applyBase) {
    case 'PRINCIPAL':
      return Math.max(principal - paid, 0);
    case 'PRINCIPAL_PLUS_TAX':
      return Math.max(principal + tax - paid, 0);
    case 'OUTSTANDING':
    default:
      return Math.max((principal + tax + late - discount) - paid, 0);
  }
};

// Helper: late fee math logic
const calcLateFeeForDays = ({ feeType, feeValue, days, base, compounding }) => {
  let total = 0;
  const dailyRate = Number(feeValue) / 100;

  if (feeType === 'FIXED_ONCE') {
    total = days > 0 ? Number(feeValue) : 0;
  } else if (feeType === 'PER_DAY_FIXED') {
    total = Number(feeValue) * days;
  } else if (feeType === 'PER_DAY_PERCENT') {
    if (!compounding) {
      // ✅ Simple interest
      total = base * dailyRate * days;
    } else {
      // ✅ Compound interest (daily)
      let amount = base;
      for (let i = 0; i < days; i++) {
        const inc = amount * dailyRate;
        total += inc;
        amount += inc;
      }
    }
  }
  return round2(total);
};

// Core function: apply late fee for one invoice
const applyLateFeeForInvoice = async ({
  invoice,
  rule,
  asOfDate,
  daysToApply,
  reason,
  idempotencyKey,
  actorUserId
}) => {
  const ns = getNamespace();
  const tenantId = ns.get('tenantId');
  const applicationId = invoice.applicationId;

  console.log('──────────── LATE FEE DEBUG ────────────');
  console.log('TenantId:', tenantId);
  console.log('ApplicationId:', applicationId);
  console.log('InvoiceId:', invoice.id);
  console.log('AsOfDate:', asOfDate, '| DaysToApply:', daysToApply);
  console.log('Sequelize connected to:', sequelize.config.database);
  console.log('LateFeeEvent table name:', LateFeeEvent.getTableName());

  if (!invoice.dueDate) {
    console.warn('⛔ Skipping: invoice has no dueDate');
    return null;
  }
  if (!['pending', 'partial', 'expired'].includes(invoice.status)) {
    console.warn('⛔ Skipping: invoice status not eligible →', invoice.status);
    return null;
  }

  const base = computeBase(invoice, rule.applyBase);
  console.log('Computed base amount:', base);
  if (base <= 0) {
    console.warn('⛔ Skipping: base <= 0');
    return null;
  }

  // Cap logic
  const principal = Number(invoice.subtotal || invoice.amount || invoice.totalAmount || 0);
  const capAbs = rule.maxCapPercentOfPrincipal
    ? (principal * Number(rule.maxCapPercentOfPrincipal) / 100)
    : null;
  const already = Number(invoice.lateFeeTotal || 0);

  let amount = calcLateFeeForDays({
    feeType: rule.feeType,
    feeValue: rule.feeValue,
    days: daysToApply,
    base,
    compounding: rule.compounding
  });

  if (capAbs && already + amount > capAbs) {
    amount = Math.max(capAbs - already, 0);
  }
  if (amount <= 0) {
    console.warn('⛔ Skipping: calculated amount <= 0');
    return null;
  }

  // Transaction block with explicit logging
  try {
    const result = await sequelize.transaction(async (t) => {
      console.log('➡️ Inserting LateFeeEvent...');

      const event = await LateFeeEvent.create({
        tenantId,
        applicationId,
        invoiceId: invoice.id,
        ruleId: rule.id,
        eventDate: asOfDate,
        daysLateAppliedFor: daysToApply,
        calculatedBase: base,
        amount,
        reason: reason || null,
        idempotencyKey: idempotencyKey || null,
        createdBy: actorUserId || null
      }, { transaction: t });

      console.log('✅ LateFeeEvent created:', event.id);

      // Update invoice totals
      invoice.lateFeeTotal = round2(Number(invoice.lateFeeTotal || 0) + amount);
      invoice.lastLateFeeCalcAt = new Date();

      if (new Date(asOfDate) > new Date(invoice.dueDate) && invoice.status === 'pending') {
        invoice.status = 'expired';
      }

      await invoice.save({ transaction: t });
      console.log('✅ Invoice updated lateFeeTotal →', invoice.lateFeeTotal);

      auditLogger.log('invoice.latefee.applied', {
        tenantId,
        applicationId,
        invoiceId: invoice.id,
        amount,
        daysToApply,
        base,
        ruleId: rule.id
      });

      return { event, amountApplied: amount, newLateFeeTotal: invoice.lateFeeTotal };
    });

    console.log('💾 Transaction committed successfully');
    console.log('──────────────────────────────────────');
    return result;

  } catch (err) {
    console.error('❌ Transaction failed:', err);
    console.log('──────────────────────────────────────');
    throw err;
  }
};

module.exports = {
  applyLateFeeForInvoice,
};
