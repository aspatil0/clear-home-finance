// src/controllers/invoiceController.full.js  (Simplified for testing)
const { v4: uuidv4 } = require('uuid');
const { Invoice } = require('../models');
const Joi = require('joi');
const { AppError } = require('../middlewares/errorHandler');
const { generateInvoiceNumber } = require('../utils/invoiceNumberGenerator');
const { resolveGlobalTenant } = require('../utils/globalTenantResolver');


// --- CREATE Invoice (temporary simplified version) ---
exports.createInvoice = async (req, res, next) => {
  try {
    // Validate input
    const schema = Joi.object({
      invoiceNumber: Joi.any().forbidden().messages({
        'any.unknown': 'Manual invoiceNumber not allowed — system auto-generates it.'
      }),
      customerId: Joi.string().required(),
      applicationId: Joi.string().required(),
      tenantId: Joi.string().optional(),
      issueDate: Joi.date().required(),
      dueDate: Joi.date().required(),
      totalAmount: Joi.number().positive().required(),
      items: Joi.array().items(
        Joi.object({
          name: Joi.string().required(),
          price: Joi.number().positive().required(),
          quantity: Joi.number().positive().required()
        })
      ).required(),
      isRecurring: Joi.boolean().default(false),
      recurringRule: Joi.object().optional(),
      status: Joi.string().valid(
        'draft', 'pending', 'approved', 'paid', 'partial', 'cancelled', 'expired'
      ).default('draft'),
      amountPaid: Joi.number().min(0).optional(),
      balanceAmount: Joi.number().min(0).optional(),
      gracePeriodDays: Joi.number().min(0).optional(),
      createdBy: Joi.string().required()
    });

    const { error, value } = schema.validate(req.body);
    if (error) throw new AppError(error.details[0].message, 400);

const { applicationId, tenantId } = value;

// Generate invoice number (tenant-aware)
const invoiceNumber = await generateInvoiceNumber(applicationId, tenantId);

// Resolve globalTenantId (if exists)
const globalTenantId = await resolveGlobalTenant(applicationId, tenantId);

// Create invoice record (include globalTenantId if resolved)
const invoice = await Invoice.create({
  id: uuidv4(),
  invoiceNumber,
  globalTenantId,   // 👈 new
  ...value
});



    res.status(201).json({
      success: true,
      message: `Invoice created successfully with number ${invoiceNumber}`,
      data: invoice
    });

  } catch (err) {
    next(err);
  }
};

// --- GET all invoices (simplified) ---
exports.getAllInvoices = async (req, res, next) => {
  try {
    let {
      page = 1,
      limit = 10,
      status,
      customerId,
      applicationId,
      tenantId,
      fromDate,
      toDate
    } = req.query;

    // Convert to integers safely
    page = parseInt(page);
    limit = parseInt(limit);
    const offset = (page - 1) * limit;

    // Base where clause
    const whereClause = {};

    // Filters
    if (status) whereClause.status = status;
    if (customerId) whereClause.customerId = customerId;
    if (applicationId) whereClause.applicationId = applicationId;
    if (tenantId) whereClause.tenantId = tenantId;  

    // Date range filters
    if (fromDate && toDate) {
      whereClause[Op.or] = [
        { issueDate: { [Op.between]: [fromDate, toDate] } },
        { dueDate: { [Op.between]: [fromDate, toDate] } }
      ];
    }

    // Fetch paginated data
    const { count, rows } = await Invoice.findAndCountAll({
      where: whereClause,
      limit,
      offset,
      order: [['createdAt', 'DESC']]
    });

    // Prepare meta block
    const totalPages = Math.ceil(count / limit);

    res.status(200).json({
      success: true,
      message: 'Invoices fetched successfully',
      data: rows,
      meta: {
        page,
        limit,
        totalRecords: count,
        totalPages
      }
    });
  } catch (err) {
    next(err);
  }
};

// --- GET Invoice by ID or Invoice Number ---

/**
 * GET /api/invoices/:id
 * Supports both internal UUID and invoiceNumber lookups
 */
exports.getInvoiceById = async (req, res, next) => {
  try {
    const { id } = req.params;
    if (!id) throw new AppError('Invoice identifier missing', 400);

    // Determine lookup type (UUID vs invoiceNumber)
    const isUUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id);

    const whereClause = isUUID ? { id } : { invoiceNumber: id };

    const invoice = await Invoice.findOne({ where: whereClause });

    if (!invoice) throw new AppError('Invoice not found', 404);

    // Sanitize output (remove internal metadata)
    const sanitized = {
      invoiceNumber: invoice.invoiceNumber,
      applicationId: invoice.applicationId,
      customerId: invoice.customerId,
      status: invoice.status,
      issueDate: invoice.issueDate,
      dueDate: invoice.dueDate,
      totalAmount: invoice.totalAmount,
      amountPaid: invoice.amountPaid,
      balanceAmount: invoice.balanceAmount,
      items: invoice.items,
      isRecurring: invoice.isRecurring,
      recurringRule: invoice.recurringRule,
      gracePeriodDays: invoice.gracePeriodDays,
      createdBy: invoice.createdBy,
      createdAt: invoice.createdAt,
      cancelledAt: invoice.cancelledAt || null
    };

    res.status(200).json({
      success: true,
      message: 'Invoice fetched successfully',
      data: sanitized
    });
  } catch (err) {
    next(err);
  }
};


// --- UPDATE Invoice (mark partial, paid, etc.) ---
exports.updateInvoice = async (req, res, next) => {
  try {
    const { id } = req.params;

    // Find existing invoice
    const invoice = await Invoice.findByPk(id);
    if (!invoice) throw new AppError('Invoice not found', 404);

    const schema = Joi.object({
      amountPaid: Joi.number().min(0).required()
    });

    const { error, value } = schema.validate(req.body);
    if (error) throw new AppError(error.details[0].message, 400);

    const newAmountPaid = value.amountPaid;
    const totalAmount = parseFloat(invoice.totalAmount);
    const balanceAmount = Math.max(totalAmount - newAmountPaid, 0);

    // Determine status
    let newStatus = 'draft';
    if (newAmountPaid === 0) newStatus = 'pending';
    else if (newAmountPaid < totalAmount) newStatus = 'partial';
    else newStatus = 'paid';

    // Update invoice
    await invoice.update({
      amountPaid: newAmountPaid,
      balanceAmount,
      status: newStatus
    });

    res.status(200).json({
      success: true,
      message: `Invoice marked as ${newStatus}`,
      data: invoice
    });

  } catch (err) {
    next(err);
  }
};

// --- DELETE (Soft Cancel) Invoice ---

exports.deleteInvoice = async (req, res, next) => {
  try {
    const { id } = req.params;
    const {cancelledBy,tenantId} = req.body.cancelledBy || 'system';

    const invoice = await Invoice.findByPk(id);
    if (!invoice) throw new AppError('Invoice not found', 404);

    if (tenantId && invoice.tenantId && invoice.tenantId !== tenantId) {
      throw new AppError('Tenant mismatch — cannot cancel invoice from another tenant.', 403);
    }
    // Block deletion for paid or expired invoices
    if (['paid', 'expired'].includes(invoice.status)) {
      throw new AppError('Paid or expired invoices cannot be cancelled.', 400);
    }

    // Perform soft cancel
    await invoice.update({
      status: 'cancelled',
      cancelledAt: new Date(),
      cancelledBy
    });

    // ---- Stubbed Audit + Notification ----
    console.log(`[Audit] Invoice ${invoice.invoiceNumber} cancelled by ${cancelledBy}`);
    console.log(`[Notify] Would trigger notification: invoice-cancelled for ${invoice.invoiceNumber}`);

    res.status(200).json({
      success: true,
      message: `Invoice ${invoice.invoiceNumber} cancelled successfully.`,
      data: {
        invoiceNumber: invoice.invoiceNumber,
        tenantId: invoice.tenantId,
        status: invoice.status,
        cancelledAt: invoice.cancelledAt,
        cancelledBy: invoice.cancelledBy
      }
    });

  } catch (err) {
    next(err);
  }
};

