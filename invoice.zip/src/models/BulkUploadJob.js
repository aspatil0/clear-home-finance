// src/models/BulkUploadJob.js
const { DataTypes } = require('sequelize');

/**
 * BulkUploadJob
 * --------------
 * Tracks each bulk invoice upload request initiated by a tenant.
 * Every row in this table represents a single upload job
 * (e.g., a CSV file or a recurring generation request).
 */
module.exports = (sequelize) => {
  const BulkUploadJob = sequelize.define('BulkUploadJob', {
    id: {
      type: DataTypes.UUID,
      primaryKey: true,
      defaultValue: DataTypes.UUIDV4,
      comment: 'Unique job identifier',
    },

    tenantId: {
      type: DataTypes.STRING(64),
      allowNull: false,
      comment: 'Tenant identifier from CLS context',
    },

    applicationId: {
      type: DataTypes.STRING(64),
      allowNull: false,
      comment: 'Application under which invoices are generated (e.g., HOUSING)',
    },

    fileId: {
      type: DataTypes.STRING(128),
      allowNull: false,
      comment: 'Reference ID from File Management microservice',
    },

    mode: {
      type: DataTypes.ENUM('one_time', 'recurring'),
      allowNull: false,
      defaultValue: 'one_time',
      comment: 'Specifies if the bulk job is one-time or recurring',
    },

    status: {
      type: DataTypes.ENUM('PENDING', 'IN_PROGRESS', 'COMPLETED', 'FAILED'),
      allowNull: false,
      defaultValue: 'PENDING',
      comment: 'Current state of bulk job processing',
    },

    totalRecords: {
      type: DataTypes.INTEGER.UNSIGNED,
      defaultValue: 0,
      comment: 'Total number of records detected in file',
    },

    processedCount: {
      type: DataTypes.INTEGER.UNSIGNED,
      defaultValue: 0,
      comment: 'Total number of records attempted (success + failure + skipped)',
    },

    successCount: {
      type: DataTypes.INTEGER.UNSIGNED,
      defaultValue: 0,
      comment: 'Number of successfully processed invoices',
    },

    failureCount: {
      type: DataTypes.INTEGER.UNSIGNED,
      defaultValue: 0,
      comment: 'Number of failed invoices',
    },

    progressPercent: {
      type: DataTypes.DECIMAL(5, 2),
      defaultValue: 0.0,
      comment: 'Percentage of file processed for live progress tracking',
    },

    errorDetails: {
      type: DataTypes.JSON,
      allowNull: true,
      comment: 'Row-level validation or creation errors captured during job',
    },

    errorLog: {
      type: DataTypes.TEXT('long'),
      allowNull: true,
      comment: 'Serialized error details for failed rows (JSON or text)',
    },

    currency: {
      type: DataTypes.STRING(8),
      allowNull: false,
      defaultValue: 'INR',
      comment: 'Default currency context for this job',
    },

    createdBy: {
      type: DataTypes.STRING(64),
      allowNull: false,
      comment: 'User ID who initiated upload',
    },

    startedAt: {
      type: DataTypes.DATE,
      allowNull: true,
      comment: 'Timestamp when job processing started',
    },

    completedAt: {
      type: DataTypes.DATE,
      allowNull: true,
      comment: 'Timestamp when job processing finished',
    },
  },
  {
    tableName: 'bulk_upload_jobs',
    timestamps: true, // adds createdAt & updatedAt
    indexes: [
      { fields: ['tenantId', 'applicationId'] },
      { fields: ['status'] },
    ],
  });

  return BulkUploadJob;
};
